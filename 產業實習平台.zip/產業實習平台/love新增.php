  <?php
  $intern_id=$_GET['intern_id'];
  $severname='localhost';
  $username='root';
  $database='finalhw';
  $table='announce';
  $userid=$_SESSION['userid'];

  $link=mysqli_connect($severname, $username);
  mysqli_select_db($link,$database);
  mysqli_set_charset($link, 'utf8');
  $sql="SELECT DISTINCT * FROM announce WHERE intern_id='$intern_id'";

  $result = mysqli_query($link,$sql);

  if($row=mysqli_fetch_assoc($result)){
      $begintime=$row["begintime"];
      $endtime=$row["endtime"];
      $detail=$row["detail"];
      $entname=$row["entname"];
      $interntype=$row["interntype"];
      $tag=$row["tag"];
  }
  $sql="insert into love(intern_id,userid,begintime,entname,endtime,detail,interntype,tag) values('$intern_id','$userid','$begintime','$entname','$endtime','$detail','$interntype','$tag')";

  
  if (mysqli_query($link,$sql)){
    echo "新增完成";
    header("Location:menu.php");
  }
  else{
      echo "新增失敗";
  }
     



  ?>
  