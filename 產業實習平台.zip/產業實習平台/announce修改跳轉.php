<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $sql="select * from announce";
    $table='announce';
    $company_name=$_POST["company_name"];
    @$begtime=$_POST["begtime"];
    @$endtime=$_POST["endtime"];
    @$treatment=$_POST["treatment"];
    @$interntype=$_POST["interntype"];
    @$place=$_POST["place"];
    @$map=$_POST["map"];
    @$detail=$_POST["detail"];
    @$tag=$_POST["tags"];
    @$intern_id=$_POST["intern_id"];

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="update announce set entname='$company_name',interntype='$interntype', begintime='$begtime', endtime='$endtime', treatment='$treatment', place='$place', map='$map', detail='$detail',tag='$tag' where intern_id=$intern_id;";
    echo "是否有街到值",$sql;

     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data.php");
     }
     else{
        echo "新增失敗";
     }

?>