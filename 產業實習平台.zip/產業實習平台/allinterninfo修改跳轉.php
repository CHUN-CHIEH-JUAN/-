<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $sql="select * from allinterninfo";
    $table='allinterninfo';
    @$begtime=$_POST["begintime"];
    @$endtime=$_POST["endtime"];
    $studentname=$_POST["studentname"];
    @$student_id=$_POST["student_id"];
    $interntype=$_POST["interntype"];
    @$entername=$_POST["entername"];
    @$detail=$_POST["detail"];
    $intern_id=$_POST["intern_id"];

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="update allinterninfo set entername='$entername', begintime='$begtime', endtime='$endtime', student_id='$student_id', studentname='$studentname',detail='$detail',interntype='$interntype' where intern_id=$intern_id;";
    echo "是否有街到值",$sql;

     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data2.php");
     }
     else{
        echo "新增失敗";
     }

?>