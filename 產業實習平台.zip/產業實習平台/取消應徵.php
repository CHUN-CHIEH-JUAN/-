<?php
  $intern_id=$_GET['intern_id'];
  $severname='localhost';
  $username='root';
  $database='finalhw';
  $table='apply';
  if($_SESSION['level']=='student'){
    $userid=$_SESSION['userid'];
  }else{
    $userid=$_GET['userid'];
  }

  $link=mysqli_connect($severname, $username);
  mysqli_select_db($link,$database);
  mysqli_set_charset($link, 'utf8');
  $sql="delete from apply WHERE userid = '$userid' and intern_id='$intern_id'";
  echo $sql;
  if (mysqli_query($link,$sql)and $_SESSION['level']=='student'){
  
     
?>

<script>
  alert('取消應徵成功');
  history.back();
  
</script>

<?php
 

}elseif(mysqli_query($link,$sql)and $_SESSION['level']=='enter'){
     
  header("Location:收到的應徵.php");
  

   }
 ?>
