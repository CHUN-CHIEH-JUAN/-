<?php


$severname='localhost';
$username='root';
$database='finalhw';
$table='apply';
$userid=$_SESSION['userid'];
$intern_id=$_GET["intern_id"];


echo"$intern_id";
$link=mysqli_connect($severname, $username);
mysqli_select_db($link,$database);
mysqli_set_charset($link, 'utf8');

$sql="insert into apply(userid,intern_id) values('$userid',$intern_id)";
echo"$sql";
$sql2="delete from love WHERE intern_id = $intern_id and userid='$userid'";

 if (mysqli_query($link,$sql)){
    if (mysqli_query($link,$sql2)){
      echo'';
      }
  
    
 ?>
 
 <script>
   alert('應徵成功');
   history.back();
 </script>
 
 <?php
  }else{
    ?>
    
    <script>
      alert('應徵失敗');
      history.back();
    </script>
    
    <?php
     }





