<?php
  $intern_id=$_GET['intern_id'];
  $severname='localhost';
  $username='root';
  $database='finalhw';
  $table='announce';

  $link=mysqli_connect($severname, $username);
  mysqli_select_db($link,$database);
  mysqli_set_charset($link, 'utf8');
  $sql="delete from announce WHERE intern_id = $intern_id";
  echo $sql;
  if (mysqli_query($link,$sql)){
     echo "新增完成";
     header("Location: data.php");
  }
  else{
     echo "新增失敗";
  
  }
?>
