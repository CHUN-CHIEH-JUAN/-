<?php
  $intern_id=$_GET['intern_id'];
  $severname='localhost';
  $username='root';
  $database='finalhw';
  $table='report';
  $userid=$_SESSION['userid'];

  $link=mysqli_connect($severname, $username);
  mysqli_select_db($link,$database);
  mysqli_set_charset($link, 'utf8');
  $sql="delete from report WHERE intern_id = $intern_id and userid='$userid'";
  echo $sql;
  if (mysqli_query($link,$sql)){
     echo "新增完成";
     header("Location: data3.php");
  }
  else{
     echo "新增失敗";
  
  }
?>
