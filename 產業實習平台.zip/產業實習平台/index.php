<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">

  <title> 產業實習平台 </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ==" crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
    body {
        background-image: url('images/bg8.jpg');
        background-size: cover; /* 背景图片将覆盖整个页面 */
        background-repeat: no-repeat; /* 不重复背景图 */
        background-position: center; /* 背景图片居中 */
        margin: 0;
        padding: 0;
    }
</style>

</head>

<body>

  <div class="hero_area">
    <div class="bg-box">
    </div>
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span>
              產業實習平台
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mx-auto ">
              <li class="nav-item">
                <a class="nav-link" href="index.php">首頁</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="menu.php">實習資訊</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data.php">資訊管理</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data2.php">實習資料管理</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="data3.php">實習報告書上傳</a>
              </li>
            </ul>
            <?php
            if($_SESSION['level']<>"student" and $_SESSION['level']<>"aaa" and $_SESSION['level']<>"enter" and $_SESSION['level']<>"school"){
              echo '
              <div class="user_option">
                <div class="container3">
                  <div class="btn-box3" style="padding: 3px 10px; border: 1px solid #fff; border-radius: 5px;">
                    <a href="login1.php" style="color: white; font-weight: bold; font-size: 16px; padding: 3px 8px; text-decoration: none;">login</a>
                  </div>
                </div>
              ';

            }
            else{

              echo '
              <div class="user_option">
                <div class="container3">
                  <div class="btn-box3" style="padding: 3px 10px; border: 1px solid #fff; border-radius: 5px;">
                    <a href="logout.php" style="color: white; font-weight: bold; font-size: 16px; padding: 3px 8px; text-decoration: none;">logout</a>
                  </div>
                </div>
              ';
            }
            
            
            ?>
              <a class="cart_link" href="love.php">
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 456.029 456.029" style="enable-background:new 0 0 456.029 456.029;" xml:space="preserve">
                  <g>
                    <g>
                      <path d="M345.6,338.862c-29.184,0-53.248,23.552-53.248,53.248c0,29.184,23.552,53.248,53.248,53.248
                   c29.184,0,53.248-23.552,53.248-53.248C398.336,362.926,374.784,338.862,345.6,338.862z" />
                    </g>
                  </g>
                  <g>
                    <g>
                      <path d="M439.296,84.91c-1.024,0-2.56-0.512-4.096-0.512H112.64l-5.12-34.304C104.448,27.566,84.992,10.67,61.952,10.67H20.48
                   C9.216,10.67,0,19.886,0,31.15c0,11.264,9.216,20.48,20.48,20.48h41.472c2.56,0,4.608,2.048,5.12,4.608l31.744,216.064
                   c4.096,27.136,27.648,47.616,55.296,47.616h212.992c26.624,0,49.664-18.944,55.296-45.056l33.28-166.4
                   C457.728,97.71,450.56,86.958,439.296,84.91z" />
                    </g>
                  </g>
                  <g>
                    <g>
                      <path d="M215.04,389.55c-1.024-28.16-24.576-50.688-52.736-50.688c-29.696,1.536-52.224,26.112-51.2,55.296
                   c1.024,28.16,24.064,50.688,52.224,50.688h1.024C193.536,443.31,216.576,418.734,215.04,389.55z" />
                    </g>
                  </g>
                  <g>
                  </g>
                  <g>
                      <path d="M439.296,84.91c-1.024,0-2.56-0.512-4.096-0.512H112.64l-5.12-34.304C104.448,27.566,84.992,10.67,61.952,10.67H20.48
                   C9.216,10.67,0,19.886,0,31.15c0,11.264,9.216,20.48,20.48,20.48h41.472c2.56,0,4.608,2.048,5.12,4.608l31.744,216.064
                   c4.096,27.136,27.648,47.616,55.296,47.616h212.992c26.624,0,49.664-18.944,55.296-45.056l33.28-166.4
                   C457.728,97.71,450.56,86.958,439.296,84.91z" />
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                  <g>
                  </g>
                </svg>
              </a>
              <form class="form-inline" action=user修改.php>
                <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit">
                  <i class="fa fa-user" aria-hidden="true"></i>
                </button>
              </form>
            </div>
          </div>
        </nav>
      </div>


      <section class="offer_section layout_padding-bottom">
        <div class="offer_container">
          <div class="container">
            <div class="row">
              <!-- 企業登入 -->
              <div class="col-md-4">
                <div class="box">
                  <div class="img-box">
                    <img src="images/company1.jpg" alt="">
                  </div>
                  <div class="detail-box">
                    <h4>我是企業</h4>
                    <a href="login1.php">
                      login Now 
                      <!-- SVG icon code -->
                    </a>
                  </div>
                </div>
              </div>
              <!-- 系所登入 -->
              <div class="col-md-4">
                <div class="box">
                  <div class="img-box">
                    <img src="images/school2.jpg" alt="">
                  </div>
                  <div class="detail-box">
                    <h4>我是系所</h4>
                    <a href="login1.php">
                      login Now 
                      <!-- SVG icon code -->
                    </a>
                  </div>
                </div>
              </div>
              <!-- 學生登入 -->
              <div class="col-md-4">
                <div class="box">
                  <div class="img-box">
                    <img src="images/student2.jpg" alt="">
                  </div>
                  <div class="detail-box">
                    <h4>我是學生</h4>
                    <a href="login1.php">
                      login Now 
                      <!-- SVG icon code -->
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </header>
 </div>

 <footer class="footer_section">
    <div class="container">
      <div class="row">
        <div class="col-md-4 footer-col">
          <div class="footer_contact">
            <h4>
              Contact Us
            </h4>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps?sca_esv=87ab822241439fb3&rlz=1C1GCEA_enTW1015TW1015&output=search&q=%E8%BC%94%E4%BB%81%E5%A4%A7%E5%AD%B8&source=lnms&fbs=AEQNm0AaBOazvTRM_Uafu9eNJJzCbF5Xkn0WmZWrNBlhQ5AQFOZM5xYdfIIIZQZe9lZbbb_RfRT2wJ1IEkGUzBkC-RHweJLsr2JXbnYLNuAycd5HN1ZFDsEPelupJ34pLAPcsLdr8YIoquSpSQNSPOiiT7Yx2Xm_HDLas01pm-5u3zO2awUT2BdnVRHIaVI1qqNXis4hewyi&entry=mc&ved=1t:200715&ictx=111">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="https://www.fju.edu.tw/">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  webside
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call (02) 29052000
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                pubwww@mail.fju.edu.tw
                </span>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <div class="footer_detail">
            <a href="" class="footer-logo">
              F J C U
            </a>
            <p>
            天主教輔仁大學</br></br>
            為追求真、善、美、聖，全人教育之師生共同體，
            致力於中華文化與基督信仰之交融，
            以基督博愛精神，
            獻身於學術研究與弘揚真理，
            促進社會永續均衡發展，
            增進人類社會福祉，
            以達到知人、知物、知天之合一理想。
            </p>
            <div class="footer_social">
              <a href="https://www.facebook.com/FuJenCatholicUniversity/?locale=zh_TW">
                <i class="fa fa-facebook" aria-hidden="true"></i>
              </a>
              <a href="https://www.instagram.com/fujencatholicuniversity/">
                <i class="fa fa-instagram" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <h4>
            Opening Hours
          </h4>
          <p>
            Everyday
          </p>
          <p>
            10.00 Am -10.00 Pm
          </p>
        </div>
      </div>
    </div>
  </footer>
 
  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- isotope js -->
  <script src="https://unpkg.com/isotope-layout@3.0.4/dist/isotope.pkgd.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

</body>

</html>