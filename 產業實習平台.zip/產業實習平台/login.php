<?php

$userid = $_POST["userid"];
$password = $_POST["password"];
$severname='localhost';
$username='root';
$database='finalhw';
$table='allinterninfo';
$link=mysqli_connect($severname, $username);
mysqli_select_db($link,$database);
mysqli_set_charset($link, 'utf8');
$sql="select * from login where userid='$userid' and passwords ='$password'";
$rs=mysqli_query($link, $sql);
If( $record=mysqli_fetch_assoc($rs))
{$_SESSION['user'] = $record['username'];
$_SESSION['level'] = $record['levels'];
$_SESSION['userid'] = $record['userid'];
$_SESSION['passwords'] = $record['passwords'];
?>
<script>
    alert('登入成功');
    window.location.href = "loginindex.php";
</script>
<?php
}
else{ ?>
<script>
    alert('登入失敗');
    window.location.href = "index.php";
</script>

<?php
}
?>
