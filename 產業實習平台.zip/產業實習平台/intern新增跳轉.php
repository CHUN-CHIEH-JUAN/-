<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $sql="select * from allinterninfo";
    $table='allinterninfo';
    $student_id=$_POST["student_id"];
    $company_name=$_POST["company_name"];
    $student_name=$_POST["student_name"];
    @$start_date=$_POST["start_date"];
    @$end_date=$_POST["end_date"];
    $internship_description=$_POST["internship_description"];
    $interntype=$_POST["interntype"];
  

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="insert into allinterninfo(student_id,studentname,entername,begintime,endtime,detail,interntype) values('$student_id','$student_name','$company_name','$start_date','$end_date','$internship_description','$interntype');";
     echo "是否有街到值",$sql;

     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data2.php");
     }
     else{
        echo "新增失敗";
     }

?>