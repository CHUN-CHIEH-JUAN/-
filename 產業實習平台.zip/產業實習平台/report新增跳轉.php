<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $table='report';
    $userid=$_SESSION['userid'];
    $entername=$_POST["entername"];
    @$begtime=$_POST["begtime"];
    @$endtime=$_POST["endtime"];
    $interntype=$_POST["interntype"];
    @$detail=$_POST["detail"];
    

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="insert into report(userid,entername,interntype,begintime,endtime,detail) values('$userid','$entername','$interntype','$begtime','$endtime','$detail')";
     
    
     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data3.php");
     }
     else{
        echo "新增失敗";
     }

?>