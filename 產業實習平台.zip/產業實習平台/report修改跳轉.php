<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $table='report';
    $userid=$_SESSION['userid'];
    $entername=$_POST["entername"];
    @$begintime=$_POST["begintime"];
    @$endtime=$_POST["endtime"];
    $interntype=$_POST["interntype"];
    @$detail=$_POST["detail"];
    $intern_id=$_POST["intern_id"];
    

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="update report set entername='$entername', begintime='$begintime', endtime='$endtime', interntype='$interntype', detail='$detail' where intern_id=$intern_id;";
    
    
     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data3.php");
     }
     else{
        echo "新增失敗";
     }

?>