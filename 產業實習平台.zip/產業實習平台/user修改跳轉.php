<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $table='login';
    $userid=$_SESSION['userid'];
    $user=$_POST["user"];

    $department=$_POST["department"];
    $selfintro=$_POST["selfintro"];
    $contact=$_POST["contact"];


  



    $link = mysqli_connect($severname, $username);
    mysqli_select_db($link, $database);
    mysqli_set_charset($link, 'utf8');
      $check_sql = "SELECT COUNT(*) as count FROM userdata WHERE userid = '$userid';";
      $result = mysqli_query($link, $check_sql);
      $row = mysqli_fetch_assoc($result);
      echo "INSERT INTO userdata(userid, username, selfintro, department,contact) VALUES('$userid', '$user', '$selfintro', '$department','$contact');";
      echo "UPDATE login SET username = '$user' WHERE userid = '$userid';";
      
         
      if ($row['count'] > 0) {
         $update_login_sql = "UPDATE login SET username = '$user' WHERE userid = '$userid';";
         $update_userdata_sql = "UPDATE userdata SET username = '$user', selfintro = '$selfintro', department = '$department',contact='$contact' WHERE userid = '$userid';";
         
         if (mysqli_query($link, $update_login_sql) && mysqli_query($link, $update_userdata_sql)) {
            echo "修改完成";
            $_SESSION['user']=$user;
            header("Location:user修改.php");

         } else {
            echo "修改失敗";
            
         }
      } else {
         
         $insert_sql = "INSERT INTO userdata(userid, username, selfintro, department,contact) VALUES('$userid', '$user', '$selfintro', '$department','$contact');";

         if (mysqli_query($link, $insert_sql)) {
            echo "新增完成";
            $_SESSION['user']=$user;
            header("Location:user修改.php");
         } else {
            echo "新增失敗";
         }
      }
      ?>
