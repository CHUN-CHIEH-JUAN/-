<?php
 //權限判斷
 if($_SESSION['level']<>"student" and $_SESSION['level']<>"aaa" and $_SESSION['level']<>"enter" and $_SESSION['level']<>"school"){

?>

<script>
  alert('要登入才能使用喔');
  history.back();
</script>

<?php
 }
 ?>

<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $table='login';


    $userid=$_SESSION['userid'];
    $passwords=$_SESSION['passwords'];

    $old_password=$_POST["old_password"];
    $new_password=$_POST["new_password"];
    $new_password1=$_POST["new_password1"];

    
     
   if($passwords!=$old_password){

   ?>
   
   <script>
     alert('舊密碼輸入錯誤，如忘記密碼請洽校方');
     $judgepw=false;
     history.back();
   </script>
   
   <?php
    }else{
      $judgepw=true;
    }



   //權限判斷
   if($new_password!=$new_password1){

   ?>
   
   <script>
      alert('兩次密碼輸入不同');
      $comfirm_new_pw=false;
      history.back();
   </script>
   
   <?php
      }else{
         $comfirm_new_pw=true;
      }
   if($judgepw==true and $comfirm_new_pw==true){
   $_SESSION['passwords']=$new_password;
    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="update login set passwords='$new_password' where userid='$userid';";
      if (mysqli_query($link,$sql)){

         ?>
            
         <script>
            alert('修改完成');
            history.back();
         </script>
         <?php
      }}
?>