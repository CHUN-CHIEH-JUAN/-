<?php
    $severname='localhost';
    $username='root';
    $database='finalhw';
    $table='announce';
    $userid=$_SESSION['userid'];
    $company_name=$_POST["company_name"];
    @$begtime=$_POST["begtime"];
    @$endtime=$_POST["endtime"];
    $treatment=$_POST["treatment"];
    $interntype=$_POST["interntype"];
    @$place=$_POST["place"];
    @$map=$_POST["map"];
    @$detail=$_POST["detail"];
    $tags=$_POST["tags"];
    

    $link=mysqli_connect($severname, $username);
    mysqli_select_db($link,$database);
    mysqli_set_charset($link, 'utf8');

    $sql="insert into announce(entname,begintime,endtime,treatment,place,map,detail,userid,interntype,tag) values('$company_name','$begtime','$endtime','$treatment','$place','$map','$detail','$userid','$interntype','$tags')";
     
    
     if (mysqli_query($link,$sql)){
        echo "新增完成";
        header("Location:data.php");
     }
     else{
        echo "新增失敗";
     }

?>