<?php
  $love_id=$_GET['love_id'];
  $severname='localhost';
  $username='root';
  $database='finalhw';
  $table='love';
  $userid=$_SESSION['userid'];

  $link=mysqli_connect($severname, $username);
  mysqli_select_db($link,$database);
  mysqli_set_charset($link, 'utf8');
  $sql="delete from love WHERE love_id = $love_id and userid='$userid'";
  echo $sql;
  if (mysqli_query($link,$sql)){
     
?>

<script>
  alert('取消關注成功');
  history.back();
</script>

<?php
 }
 ?>
