<?php
    session_start();
    $_SESSION['user'] = "";
    $_SESSION['level'] ="";
    echo "登出成功";
    ?>
<script>
    alert('登出成功');
    window.location.href = "index.php";
</script>
